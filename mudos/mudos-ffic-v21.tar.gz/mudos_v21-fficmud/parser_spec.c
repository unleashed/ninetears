#include "spec.h"

void parse_init();
void parse_refresh();
int parse_sentence(string, void | int);
void parse_add_rule(string, string, object);
string parse_dump();
mixed parse_my_rules(object, string, void | int);
