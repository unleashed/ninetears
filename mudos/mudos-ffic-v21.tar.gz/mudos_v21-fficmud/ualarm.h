#ifndef _UALARM_H_
#define _UALARM_H_
#ifndef HAS_UALARM
#include "std.h"

unsigned ualarm(unsigned usecs, unsigned reload);

#endif	/* HAS_UALARM */
#endif  /* _UALARM_H_ */
