/* used by sprintf.c */

#define IGNORE_C1 '%'
#define IGNORE_C2 '^'
