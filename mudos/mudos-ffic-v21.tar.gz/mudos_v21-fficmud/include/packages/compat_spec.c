#include "spec.h"

int cat(string, void|int, void|int);
void log_file(string, string);
string extract(string, void|int, void|int);
object next_living(object);
object first_inventory(object|string default: F_THIS_OBJECT);
object next_inventory(object default: F_THIS_OBJECT);
