#ifndef DUMPSTAT_H
#define DUMPSTAT_H

/*
 * dumpstat.c
 */
int data_size PROT((object_t *));
void dumpstat PROT((char *));

#endif
