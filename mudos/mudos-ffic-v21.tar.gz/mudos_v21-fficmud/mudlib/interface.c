#include "std.h"
#include "interface.h"
#include "lpc_to_c.h"

#ifdef sgi
int SGI_should_be_shot_for_including_stupid_bugs_in_ar;
#endif

#ifdef LPC_TO_C
interface_t *interface[] = {
    0
};
#endif
