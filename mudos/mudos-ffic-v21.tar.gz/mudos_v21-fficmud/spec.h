#define _FUNC_SPEC_
#include "std.h"
