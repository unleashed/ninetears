#ifndef CLASS_H
#define CLASS_H

void dealloc_class PROT((array_t *));
array_t *allocate_class PROT((class_def_t *));

#endif
