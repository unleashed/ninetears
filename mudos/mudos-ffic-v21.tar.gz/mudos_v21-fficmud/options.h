/*
 * options.h: defines for the compile-time configuration of the MudOS driver
 */

#include "local_options"
