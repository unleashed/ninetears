#ifndef STRSTR_H
#define STRSTR_H

/*
 * strstr.c
 */
char *_strstr PROT((char *, char *));

#endif
