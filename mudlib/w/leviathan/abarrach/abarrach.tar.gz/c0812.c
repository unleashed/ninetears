// Minimap 2.3b.   (c) 1998 Spp .
// By Dagda
#include "/d/abarrach/path.h"
inherit "/d/abarrach/handler/base_abarrach.c";

void setup()
{
   set_short("corta");
   set_long("larga.\n");
   add_clone("npcs",1);
   add_exit("norte"   ,CIUDAD"c0712.c","road");
   add_exit("oeste"   ,CIUDAD"c0811.c","road");
   add_exit("este"    ,CIUDAD"c0813.c","road");
   add_exit("sur"     ,CIUDAD"c0912.c","road");
}