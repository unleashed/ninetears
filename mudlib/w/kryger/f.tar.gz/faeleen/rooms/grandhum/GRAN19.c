#include "../../path.h"
inherit "/std/outside.c";
 void setup()
{
set_short("Poblado de Grandhum: Entramado de calles%^RESET%^");
set_long("Poblado de Grandhum: Entramado de calles%^RESET%^\n\n Estas "
    " en unauna de las estrechas calles de grandhum,ves pocas calles a tu alrededor"
    " y las casas son de poco tamanyo. Puedes observar que en la mayoria"
    " de las ventanas de las casas tienen maceteros con flores Pretyus,  "
    " una flor de la zona .\n\n");
          
set_light(50);
set_zone("Grandhum");
add_clone(NPC+"comerciante_grandhum.c",1); 
add_exit("oeste",ROOMGRAN"GRAN18.c","road");
add_exit("noreste",ROOMGRAN"GRAN20.c","road");
}