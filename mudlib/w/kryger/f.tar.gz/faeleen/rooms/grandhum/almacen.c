#include "../../path.h"
inherit "/std/room";
 
 void setup() {
   add_clone("/d/faeleen/obj/capa_pretyus.c",1);
   add_clone("/d/faeleen/obj/cinta_pretyus.c",1);
   add_clone("/d/faeleen/obj/pantalon_pretyus.c",1);
   add_clone("/d/faeleen/obj/camisa_pretyus.c",1); 
 }
