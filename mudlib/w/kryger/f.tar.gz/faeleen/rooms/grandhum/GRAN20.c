#include "../../path.h"
inherit "/std/outside.c";
 void setup()
{
set_short("Poblado de Grandhum: Entramado de calles%^RESET%^");
set_long("Poblado de Grandhum: Entramado de calles%^RESET%^\n\n Estas "
    " en unauna de las estrechas calles de grandhum,ves pocas calles a tu alrededor"
    " y las casas son de poco tamanyo. Puedes observar que en la mayoria"
    " de las ventanas de las casas tienen maceteros con flores Pretyus,  "
    " una flor de la zona." 
    "Al sudeste ves una salida a unos cultivos.\n\n");
          
set_light(50);
set_zone("Grandhum");
add_clone(NPC+"habitante2_grandhum.c",2); 
add_exit("oeste",ROOMGRAN"GRAN19.c","road");
add_exit("noreste",ROOMGRAN"GRAN21.c","road");
add_exit("sudeste",ROOMGRAN"CUL15.c","road");
}