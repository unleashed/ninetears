#include "../../path.h"
inherit "/std/outside.c";
 void setup()
{
set_short("Poblado de Grandhum: Entrada%^RESET%^");
set_long("Poblado de Grandhum: Entrada%^RESET%^\n\n Estas en la"
    " entrada del pequenyo poblado de grandhum,ves pocas calles "
    " y las casas son de poco tamanyo. Puedes observar que en la mayoria"
    " de las ventanas de las casas tienen maceteros con flores Pretyus,  "
    " una flor de la zona .\n\n");
          
set_light(50);
set_zone("Grandhum");
add_clone(NPC+"habitante_grandhum.c",1); 
add_exit("norte",ROOMGRAN"GRAN17.c","road");
add_exit("sudoeste",ROOMGRAN"CFP12.c","road");
add_exit("oeste",ROOMGRAN"GRAN01.c","road");
add_exit("este",ROOMGRAN"GRAN18.c","road");
}