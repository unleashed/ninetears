#include "../../path.h"
inherit "/std/outside.c";
 void setup()
{
set_short("%^RED%^Camino secundario a Grandhum%^RESET%^");
set_long("%^RED%^Camino secundario a Grandhum%^RESET%^\n\n Estas en un"
    " camino que se dirige al poblado de Grandhum, al final del camino puedes "
    " observar la pequenya entrada a Grandhum, estas rodeado de"
    " diver sas flores pero la que mas destaca es la Pretyus una flor  "
    "habitual de la zona.\n\n");
 add_item("flores","Ves unas maravillosas flores de muchos colores, "
        "son las flores pretyus una especie unica en esta zona.\n");         
set_light(50);
set_zone("camino_Grandhum");
add_clone(NPC+"comerciante_grandhum.c",1); 
add_exit("este",ROOMGRAN"CFP08.c","road");
add_exit("sudoeste",ROOMGRAN"CFP10.c","road");
}